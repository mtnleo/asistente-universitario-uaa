# IA2: first offline semantic-search benchmark

## Reproduce

Run with the project's existing Python 3.12 environment. Supply the path to the repository checkout (the recorded run is on `ed5829f48b4e7e08972bb4196c6644e0f1a920bd`):

```sh
"$REPO/.venv/bin/python" evaluate.py "$REPO" --output "$PWD/results.json"
```

Keep `evaluate.py` and `gold.json` together. The pinned model/tokenizer snapshot and OCR text caches must already exist under the repository's ignored `.cache-prototype/`. Missing data fails the run rather than triggering downloads or OCR. Package versions, model revision, source file/OCR cache hashes, and gold hash are recorded in the output. No API keys, Gemini calls, network services, calendar reservations, or email. No production changes.

## What was measured

- Ten hand-labeled development questions: seven for PDFs, three for calendar, with 11 relevant evidence units in total. Gold was frozen before any ranking inspection; this is not a held-out test or an exhaustive audit of substitute evidence.
- Corpus: 19 eligible unique PDFs, 97 pages (40 from cached, unverified OCR), and 102 curated calendar records. Four local-only raw PDFs are excluded before indexing.
- Fixed original Spanish questions, same cached multilingual MiniLM model, normalized CPU embeddings, cosine search. Take up to 24 candidate chunks, collapse repeated PDF page or curated-record identities by first occurrence, then score the first k **evidence units**. k is 3 or 5, not 3 or 5 chunks. No reranking, model query reformulation, budget truncation, or dedicated calendar browse.
- Per question, Precision@k = relevant units in first k / k; Recall@k = relevant units in first k / total labeled relevant units. Report the arithmetic mean over ten questions. An alternative useful but unmarked unit is treated as nonrelevant, which can lower measured precision. Most questions have only one marked relevant unit, so raw precision at larger k has a low ceiling.

## Results

| Split size / overlap | Chunks | Max encoded length | P@3 | R@3 | P@5 | R@5 | Full recall at 5 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 100 / 15 (default) | 707 | 102 | 20.0% | 60.0% | 12.0% | 60.0% | 6/10 |
| 60 / 15 | 1,266 | 62 | 26.7% | 75.0% | 16.0% | 75.0% | 7/10 |

No chunk exceeded the encoder's 128-token input limit. Keeping absolute overlap at 15 tokens makes chunk size the sole configured change, although the overlap proportion increases as chunks get shorter.

| Question | Relevant in top 5, 100/15 | Relevant in top 5, 60/15 | Labeled |
| --- | ---: | ---: | ---: |
| Account balance inquiry | 1 | 1 | 1 |
| Early payment deadline | 1 | 1 | 1 |
| Regularity extension request | 0 | 0 | 1 |
| Teacher communication channel | 1 | 1 | 1 |
| Attendance exception | 1 | 1 | 1 |
| Data Governance prerequisites | 0 | 0 | 1 |
| July registration-date conflict | 0 | 1 | 1 |
| October special exam dates | 1 | 1 | 1 |
| December registration plus exam dates | 0 | 1 | 2 |
 
## Interpretation

- The 15-point macro Recall@5 gain is limited to calendar queries, with no PDF top-5 change. The 60-token index has 79% more chunks and the dedicated calendar route was not evaluated. This does not warrant changing the default yet.
- The regularity extension page is absent from both top-24 chunk candidate lists. The prerequisite page is rank 6 after deduplication in both; PDF content contains the right table but the leading evidence does not establish its answer. A held-out PDF set plus controlled query reformulation or hybrid retrieval would test a targeted improvement.
- A 2023 historical notice ranks ahead of the correct 2026 record for the October special exam question in both configurations. A high-ranking match is not proof of correct applicability.
- No answer quality, abstention, citation accuracy, live tool selection, dedicated calendar browse, or workflow behavior was measured. A temperature comparison should hold retrieved evidence fixed and independently score generated answers against a rubric with a small authorized free-tier request budget.

Verification: a second offline run produced byte-identical JSON; an independent recalculation matched all reported aggregate metrics.
