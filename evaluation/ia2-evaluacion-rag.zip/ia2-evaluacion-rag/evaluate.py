#!/usr/bin/env python3
"""Offline, disposable IA2 development benchmark. Use the project Python venv."""

import argparse
from collections import Counter
import hashlib
from importlib.metadata import version
import json
import os
from pathlib import Path
from statistics import mean
import subprocess
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
REVISION = "e8f8c211226b894fcb81acc59f3b34ba3efd5f42"
CONFIGS = [(100, 15), (60, 15)]
K_VALUES = (3, 5)
CANDIDATE_K = 24
SEPARATORS = ["\n\n", "\n", ". ", " ", ""]


def cached_ocr(cache, path, digest, numbers):
    file = cache / "ocr" / f"{digest}.json"
    data = json.loads(file.read_text()) if file.is_file() else {}
    missing = [n for n in numbers if not data.get(str(n), "").strip()]
    if missing:
        raise RuntimeError(f"No cached OCR for {path.name} page(s) {missing}; no fallback.")
    return data


def key(metadata):
    return (metadata["source"], metadata.get("record_id") or metadata["page"])


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("repo", type=Path)
    parser.add_argument("--output", type=Path, default=HERE / "results.json")
    args = parser.parse_args()
    repo = args.repo.resolve()
    # Read only pinned cached model files; no network/model download or credentials.
    os.environ.update(HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1",
                      HF_HUB_DISABLE_TELEMETRY="1", LANGSMITH_TRACING="false",
                      LANGCHAIN_TRACING_V2="false", TOKENIZERS_PARALLELISM="false",
                      HF_HOME=str(HERE / ".hf"))
    sys.path.insert(0, str(repo))
    import prototype_rag as rag
    import torch
    from langchain_core.documents import Document
    from langchain_core.vectorstores import InMemoryVectorStore
    from langchain_huggingface import HuggingFaceEmbeddings
    from langchain_text_splitters import RecursiveCharacterTextSplitter
    from transformers import AutoTokenizer

    torch.set_num_threads(3)
    model = "models--" + rag.EMBEDDINGS.replace("/", "--")
    snapshot = rag.CACHE / "embeddings" / model / "snapshots" / REVISION
    tok_snapshot = rag.CACHE / "tokenizer" / model / "snapshots" / REVISION
    if not snapshot.is_dir() or not tok_snapshot.is_dir():
        raise RuntimeError(f"Required model/tokenizer revision not cached: {REVISION}.")
    tokenizer = AutoTokenizer.from_pretrained(str(tok_snapshot), trust_remote_code=False,
                                              local_files_only=True, token=False)
    embeddings = HuggingFaceEmbeddings(
        model_name=str(snapshot),
        model_kwargs={"device": "cpu", "trust_remote_code": False, "token": False,
                      "local_files_only": True},
        encode_kwargs={"normalize_embeddings": True, "batch_size": 16},
    )

    gold_file = HERE / "gold.json"
    fixture = json.loads(gold_file.read_text())
    questions = fixture["questions"]
    if not questions or len({q["id"] for q in questions}) != len(questions):
        raise ValueError("Missing or duplicate question IDs.")

    # Never extract local-only docs and never invoke Swift OCR for this benchmark.
    rag.ocr_pages = lambda path, digest, numbers: cached_ocr(rag.CACHE, path, digest, numbers)
    names = sorted(p.name for p in rag.CORPUS.glob("*.pdf")
                   if p.name not in rag.LOCAL_ONLY_FILES)
    pages, extraction = rag.load_pages(names)
    if any(row.get("error_type") or row.get("failed_pages") or row.get("empty_pages")
           for row in extraction):
        raise RuntimeError("Incomplete PDF extraction; fix/record corpus coverage before scoring.")
    calendar, _ = rag.load_calendar_records()
    all_units = pages + calendar
    documents = [Document(page_content=p["text"],
                          metadata={field: p.get(field) for field in
                                    ("source", "page", "record_id", "cloud_allowed")})
                 for p in all_units]
    allowed = {key(d.metadata) for d in documents if d.metadata["cloud_allowed"] is True}
    if len(allowed) != len(documents):
        raise RuntimeError("Duplicate evidence identity or local-only evidence in evaluation.")
    gold = {q["id"]: {tuple(unit) for unit in q["gold"]} for q in questions}
    for q in questions:
        if not gold[q["id"]] or not gold[q["id"]] <= allowed:
            raise ValueError(f"Unanswerable or out-of-corpus gold: {q['id']}.")
        if len(tokenizer.encode(q["question"], add_special_tokens=True, truncation=False)) > rag.EMBEDDING_MAX_TOKENS:
            raise ValueError(f"Query exceeds production embedding limit: {q['id']}.")

    pdf_names = sorted({p["source"] for p in pages})
    git = subprocess.run(["git", "rev-parse", "HEAD"], cwd=repo, capture_output=True,
                         text=True, check=True).stdout.strip()
    result = {
        "repo_commit": git,
        "gold_sha256": sha(gold_file),
        "questions": len(questions),
        "units": {"pdfs": len(pdf_names), "pdf_pages": len(pages),
                  "ocr_unverified": sum(p["extraction"] == "ocr_unverified" for p in pages),
                  "calendar_records": len(calendar),
                  "excluded_local_only_files": sorted(rag.LOCAL_ONLY_FILES)},
        "corpus_sha256": {name: sha(rag.CORPUS / name) for name in pdf_names}
                         | {"knowledge/calendar_2026.json": sha(rag.CALENDAR_KNOWLEDGE)},
        "ocr_cache_sha256": {row["file"]: sha(rag.CACHE / "ocr" /
                                             f'{sha(rag.CORPUS / row["file"])}.json')
                             for row in extraction if row.get("ocr_unverified_pages")},
        "software": {pkg: version(pkg) for pkg in
                     ("torch", "langchain-core", "langchain-huggingface",
                      "langchain-text-splitters", "sentence-transformers", "transformers", "pypdf")},
        "model": {"name": rag.EMBEDDINGS, "snapshot": REVISION, "device": "cpu",
                  "normalize_embeddings": True, "batch_size": 16,
                  "max_tokens": rag.EMBEDDING_MAX_TOKENS},
        "protocol": {
            "query": "Original fixed Spanish question used verbatim for semantic search.",
            "candidate_chunks": CANDIDATE_K,
            "candidate_reduction": "Deduplicate top-ranked chunks by first PDF page or calendar record occurrence, then take the first k units.",
            "splitter_separators": SEPARATORS,
            "k": K_VALUES,
            "precision": "Number of relevant returned units divided by k (absent ranks score zero).",
            "recall": "Number of relevant returned units divided by labeled relevant units.",
            "macro": "Arithmetic mean over questions.",
            "scope": "Ranked document search only; no budget truncation, tool selection, date browse, or response generation.",
        },
        "configurations": [],
    }
    for size, overlap in CONFIGS:
        splitter = RecursiveCharacterTextSplitter.from_huggingface_tokenizer(
            tokenizer, chunk_size=size, chunk_overlap=overlap, separators=SEPARATORS)
        chunks = splitter.split_documents(documents)
        length = Counter(len(tokenizer.encode(c.page_content, add_special_tokens=True,
                                             truncation=False)) for c in chunks)
        over_limit = sum(count for n, count in length.items() if n > rag.EMBEDDING_MAX_TOKENS)
        if over_limit:
            raise RuntimeError(f"{over_limit} chunks exceed the model window with {size}/{overlap}.")
        print(f"Encoding {len(chunks)} chunks at {size}/{overlap} (max actual length {max(length)})",
              file=sys.stderr, flush=True)
        store = InMemoryVectorStore(embedding=embeddings)
        store.add_documents(chunks)
        rows = []
        for q in questions:
            candidates = store.similarity_search_with_score(q["question"], k=CANDIDATE_K)
            ranked = {}
            for d, score in candidates:
                ranked.setdefault(key(d.metadata), float(score))
            want = gold[q["id"]]
            entries = []
            for rank, (unit, score) in enumerate(ranked.items(), 1):
                entries.append({"rank": rank, "unit": unit, "score": score, "relevant": unit in want})
            metrics = {}
            for k in K_VALUES:
                top = set(list(ranked)[:k])
                hits = len(top & want)
                metrics[str(k)] = {"hits": hits, "returned": len(top), "precision": hits / k,
                                   "recall": hits / len(want)}
            rows.append({"id": q["id"], "question": q["question"], "gold": q["gold"],
                         "metrics": metrics, "ranked_units": entries})
        summaries = {str(k): {
            "macro_precision": mean(r["metrics"][str(k)]["precision"] for r in rows),
            "macro_recall": mean(r["metrics"][str(k)]["recall"] for r in rows),
            "questions_with_hit": sum(r["metrics"][str(k)]["hits"] > 0 for r in rows),
            "questions_with_full_recall": sum(r["metrics"][str(k)]["recall"] == 1 for r in rows),
            "gold_hits": sum(r["metrics"][str(k)]["hits"] for r in rows),
        } for k in K_VALUES}
        result["configurations"].append({"chunk_size": size, "chunk_overlap": overlap,
            "chunks": len(chunks), "max_chunk_tokens_including_special": max(length),
            "chunks_over_model_limit": over_limit, "summary": summaries, "queries": rows})
        print(f"Finished {size}/{overlap}: {json.dumps(summaries)}", file=sys.stderr, flush=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
