# IA2: paired Gemini temperature benchmark

**Keep temperature 1.0 for now.** The real Gemini comparison tied on the frozen rubric: **10/15 checks per setting**. The sample is too small to establish equivalence or recommend a change.

## Observed results

All 10 attempted requests returned text with finish reason `STOP`; Gemini identified every response as `gemini-3.1-flash-lite`. The provider did not expose a more specific revision in the recorded metadata. No retries, fallback, or extra model calls.

| Metric | 1.0 | 0.2 |
|---|---:|---:|
| Complete under the frozen case rubric | 4/5 | 4/5 |
| Grounded under the frozen case rubric | 5/5 | 5/5 |
| Valid evidence ID + PDF page | 1/5 | 1/5 |
| Valid evidence ID (regardless of page) | 5/5 | 5/5 |
| Input tokens, sum of 5 calls | 3,057 | 3,057 |
| Output tokens, sum of 5 calls | 690 | 618 |

Both temperatures gave the two July dates and corresponding annexes/pages without choosing one; neither asked for clarification about scope. Both withheld an exact fee unsupported by the supplied excerpt. The 0.2 fee answer added that amounts are fixed annually; the source establishes annual **publication** of the supplement, not the schedule for setting prices. That observation is outside the fee case's narrow frozen grounding checks. Four of five answers at each temperature cited a valid ID but omitted the PDF page; the calendar answer was the exception.

This is a small non-blinded sample, with one output per case and configuration. The 72-token observed difference is descriptive, not a stable cost or performance estimate. Keep the default (consistent with the [official Gemini 3 guide](https://ai.google.dev/gemini-api/docs/gemini-3)); investigate page attribution and scope follow-ups before tuning temperature further. See `rubric.md` for the individual judgments.

## Design

This test isolates generation. Each Spanish question was sent with the same fixed evidence and the project's answer-only system prompt. It does not measure retrieval, tool routing, action execution, or general answer quality.

| Setting | Value |
|---|---|
| Model | Existing IA2 Gemini Developer API configuration, `gemini-3.1-flash-lite` |
| Arms | `1.0` (current production configuration) and `0.2` |
| Sample | Five frozen cases, one independent response per case/arm, pair order alternates |
| Other controls | Same model, exact prompts, evidence, max output 4,096 tokens, and 45-second timeout |
| Request policy | Ten attempts maximum, at least eight seconds between starts, stop on first error, no retries or fallback |
| Data | Four short allowlisted PDF excerpts and one curated calendar record; no raw local-only PDF text, credentials or personal identifiers sent |
| Billing | The app's existing Free-tier and sharing confirmations were required. They are not a technical spending lock. No billing/account changes. |

Three binary criteria per answer were defined before any call: completeness, groundedness, and strict citation (valid evidence ID **plus PDF page**). Cases, evidence references, and the rubric are in `fixture.json`. Prompts, exact evidence, returned model name, usage, and answer text are in `live.jsonl`. Scoring is manual; no judge model was called.

## Review or reproduce locally

With the repository at the commit recorded in the journal and its existing virtual environment:

```sh
"$REPO/.venv/bin/python" -B temperature.py "$REPO"
```

This is preflight only: no credential access or network. `--live /absolute/path/to/new-journal.jsonl` makes real requests; use only when intentionally spending Free-tier quota and with a new path outside the repository. Do not repeat a failed or ambiguous request. Check `live.jsonl` for attempted calls and outcomes instead.
