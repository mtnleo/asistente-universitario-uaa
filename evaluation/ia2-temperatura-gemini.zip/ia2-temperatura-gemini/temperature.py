#!/usr/bin/env python3
"""Disposable IA2 benchmark: bounded paired Gemini calls using fixed evidence."""

import argparse
import hashlib
from importlib.metadata import version
import json
import logging
import os
from pathlib import Path
import re
import subprocess
import sys
import time
from urllib.parse import urlsplit
import warnings

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
FIXTURE = HERE / "fixture.json"
MODEL = "gemini-3.1-flash-lite"
TEMPS = (1.0, 0.2)
MAX_ATTEMPTS = 10
MIN_SECONDS_BETWEEN_STARTS = 8
ELIGIBLE_EXCERPTS = {
    ("Informacion_Basica_Administracion.pdf", 8),
    ("DSA_27_22_DURACION_REGULARIDAD.pdf", 2),
    ("reglamento_de_alumnos.pdf", 13),
    ("RR_ 231_25 LINEAMIENTOS_IAs.pdf", 3),
}
ELIGIBLE_CALENDAR = {"regular-july-registration"}


def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()


def evidence_item(rag, spec, calendar):
    """Read only the frozen allowlisted excerpt, never send its entire PDF page."""
    from langchain_core.documents import Document
    from pypdf import PdfReader

    if "record_id" in spec:
        if spec["record_id"] not in ELIGIBLE_CALENDAR:
            raise ValueError("Calendar record is not allowlisted.")
        page = calendar[spec["record_id"]]
        if page["cloud_allowed"] is not True:
            raise ValueError("Calendar record is not cloud eligible.")
        return Document(page_content=page["text"], metadata=page)
    source, number = spec["source"], spec["page"]
    if (source, number) not in ELIGIBLE_EXCERPTS or source in rag.LOCAL_ONLY_FILES:
        raise ValueError("PDF excerpt is not allowlisted.")
    pdf = PdfReader(rag.CORPUS / source)
    text = " ".join(pdf.pages[number - 1].extract_text().split())
    start = text.index(spec["start"])
    end = text.index(spec["end"], start + len(spec["start"]))
    snippet = text[start:end].strip()
    if not 0 < len(snippet) < 800 or "@" in snippet:
        raise ValueError("Unexpected excerpt length or account-like text.")
    return Document(page_content=snippet, metadata={"source": source, "page": number,
                    "extraction": "pdf", "cloud_allowed": True})


def prepare(repo):
    sys.path.insert(0, str(repo))
    import prototype_rag as rag

    if rag.MODEL != MODEL:
        raise ValueError("Unexpected application model.")
    calendar = {p["record_id"]: p for p in rag.load_calendar_records()[0]}
    fixture = FIXTURE.read_bytes()
    cases = json.loads(fixture)["cases"]
    if len(cases) != 5 or len({c["id"] for c in cases}) != 5:
        raise ValueError("Expected exactly five paired cases.")
    requests = []
    for i, case in enumerate(cases):
        docs = [(evidence_item(rag, spec, calendar), 1.0) for spec in case["evidence"]]
        evidence = rag.format_context(docs)
        human = f"Pregunta del estudiante:\n{case['question']}\n\nEvidencia recuperada (JSON):\n{evidence}"
        requests.append({"case": case["id"], "human": human,
                         "order": list(TEMPS if i % 2 == 0 else reversed(TEMPS))})
    rev = subprocess.run(["git", "rev-parse", "HEAD"], cwd=repo, capture_output=True,
                         check=True, text=True).stdout.strip()
    return rag, {
        "repo_commit": rev,
        "fixture_sha256": sha_bytes(fixture),
        "script_sha256": sha_bytes(Path(__file__).read_bytes()),
        "model_requested": MODEL,
        "sdk_versions": {p: version(p) for p in ("langchain-google-genai", "google-genai", "pypdf")},
        "timeout_seconds": 45,
        "max_output_tokens": 4096,
        "max_retries": 0,
        "min_seconds_between_attempt_starts": MIN_SECONDS_BETWEEN_STARTS,
        "max_attempts": MAX_ATTEMPTS,
        "system": rag.SYSTEM_PROMPT,
        "requests": requests,
    }


def safe_tag(value):
    return value if isinstance(value, str) and re.fullmatch(r"[A-Za-z0-9_./-]{1,100}", value) else None


def usage_counts(mapping):
    if not isinstance(mapping, dict):
        return {}
    return {k: (usage_counts(v) if isinstance(v, dict) else v)
            for k, v in mapping.items() if safe_tag(k) and
            (isinstance(v, dict) or (type(v) is int and v >= 0))}


def write_event(stream, event):
    stream.write(json.dumps(event, ensure_ascii=False) + "\n")
    stream.flush()
    os.fsync(stream.fileno())


def live(rag, manifest, path):
    from langchain_core.messages import HumanMessage, SystemMessage

    # The app's trusted credential loader is the only .env access. Its Free-tier
    # and document-sharing flags are manual confirmations, not a spending lock.
    key = rag.answer_config()
    chats = {temp: rag.make_chat(key) for temp in TEMPS}
    for temp, chat in chats.items():
        chat.temperature = temp
        chat.cache = False
        if (chat.max_retries, chat.timeout, chat.vertexai) != (0, 45, False):
            raise ValueError("Unexpected app limits or backend.")
        transport = chat.client._api_client
        url = urlsplit(str(transport._http_options.base_url))
        if (url.scheme, url.netloc, url.path.rstrip("/")) != (
            "https", "generativelanguage.googleapis.com", ""
        ):
            raise ValueError("Unexpected model endpoint.")
        # Fail closed on SDK HTTP redirects as well as model retries.
        transport._httpx_client.follow_redirects = False
        check = chat._prepare_request([SystemMessage(content="Preflight"), HumanMessage(content="Preflight")])
        if (check["config"].temperature != temp or check["config"].max_output_tokens != 4096 or
                check["config"].http_options.retry_options.attempts != 0):
            raise ValueError("SDK did not preserve experimental temperature and retry config.")

    if sum(len(r["order"]) for r in manifest["requests"]) != MAX_ATTEMPTS:
        raise ValueError("Request cap mismatch.")
    attempt = 0
    next_start = 0.0
    with path.open("x", encoding="utf-8") as journal:
        write_event(journal, {"event": "manifest", **manifest})
        for request in manifest["requests"]:
            for temp in request["order"]:
                time.sleep(max(0.0, next_start - time.monotonic()))
                attempt += 1
                entry = {"attempt": attempt, "case": request["case"], "temperature": temp}
                write_event(journal, {"event": "started", **entry})
                print(f"Attempt {attempt}/{MAX_ATTEMPTS}: {request['case']} temp={temp}", flush=True)
                start = time.monotonic()
                next_start = start + MIN_SECONDS_BETWEEN_STARTS
                try:
                    reply = chats[temp].invoke([
                        SystemMessage(content=manifest["system"]),
                        HumanMessage(content=request["human"]),
                    ])
                    answer = reply.text
                    if not answer or key in answer or reply.tool_calls:
                        raise ValueError("Invalid or unexpected model response.")
                    meta = reply.response_metadata or {}
                    write_event(journal, {"event": "response", **entry, "answer": answer,
                        "finish_reason": safe_tag(meta.get("finish_reason")),
                        "model_returned": safe_tag(meta.get("model_name") or meta.get("model_version")),
                        "usage": usage_counts(reply.usage_metadata),
                        "elapsed_seconds": round(time.monotonic() - start, 3)})
                except (Exception, KeyboardInterrupt) as exc:
                    status = getattr(exc, "status_code", None) or getattr(exc, "code", None)
                    error = type(exc).__name__
                    write_event(journal, {"event": "stopped", **entry, "error_type": error,
                                           "http_status": status if type(status) is int else None})
                    print(f"Stopped after {attempt} attempted call(s): {error}. No retries.", file=sys.stderr)
                    return 1
    return 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("repo", type=Path)
    parser.add_argument("--live", metavar="NEW_JOURNAL", type=Path,
                        help="Send up to ten real requests; otherwise only run local preflight.")
    args = parser.parse_args()
    repo = args.repo.resolve()
    logging.disable(logging.CRITICAL)
    warnings.filterwarnings("ignore")
    for key in ("HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "http_proxy", "https_proxy", "all_proxy",
                "GOOGLE_GEMINI_BASE_URL", "GOOGLE_VERTEX_BASE_URL"):
        os.environ.pop(key, None)
    os.environ.update(LANGSMITH_TRACING="false", LANGCHAIN_TRACING_V2="false",
                      LANGCHAIN_TRACING="false", GOOGLE_GENAI_USE_VERTEXAI="false",
                      OTEL_SDK_DISABLED="true")
    try:
        rag, manifest = prepare(repo)
        if not args.live:
            print(f"Preflight passed: {len(manifest['requests'])} frozen paired cases; zero calls.")
            print(f"Fixture SHA256: {manifest['fixture_sha256']}")
            return 0
        path = args.live.resolve()
        if path.is_relative_to(repo) or path.exists():
            raise ValueError("Journal must be new and outside the repository.")
        return live(rag, manifest, path)
    except (Exception, KeyboardInterrupt) as exc:
        print(f"Stopped during setup: {type(exc).__name__}. No retry attempted.", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
