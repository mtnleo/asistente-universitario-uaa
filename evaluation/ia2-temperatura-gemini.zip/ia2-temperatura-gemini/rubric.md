# Manual paired scoring

Each row scores one actual answer against the frozen case rubric: **C** complete, **G** grounded under the predeclared case criterion, **S** strict citation. A strict citation requires both the valid evidence ID and actual PDF page(s); it is more demanding than citing the ID alone.

| Case | Temp. | C | G | S | Reason |
|---|---:|---:|---:|---:|---|
| Admin balance | 1.0 | 1 | 1 | 0 | Correct opening/tracking path; [S1] but no PDF p. 8. |
| Admin balance | 0.2 | 1 | 1 | 0 | Same correct path; [S1] but no PDF p. 8. |
| Regularity extension | 1.0 | 1 | 1 | 0 | No automatic extension; faculty secretariat via Gestión de Consultas, Dean grants with reasons; [S1] but no PDF p. 2. |
| Regularity extension | 0.2 | 1 | 1 | 0 | Same route and conditional Dean decision; [S1] but no PDF p. 2. |
| July calendar conflict | 1.0 | 0 | 1 | 1 | Correct July 6 / July 2, annexes and pp. 3/9; does not pick a date, but omits the required scope follow-up. |
| July calendar conflict | 0.2 | 0 | 1 | 1 | Correct dates, annexes and pages; states no date can be assigned to the case but does not ask for scope. |
| Unsupported fee | 1.0 | 1 | 1 | 0 | No invented amount; identifies the annual supplement; [S1] but no PDF p. 13. |
| Unsupported fee | 0.2 | 1 | 1 | 0 | No invented amount, title equivalence, current applicability or nonexistent-fee claim (frozen G items); [S1] but no PDF p. 13. The answer separately overstates that amounts themselves are fixed annually; only annual publication of the supplement is explicit. |
| AI disclosure | 1.0 | 1 | 1 | 0 | Specifies type of tool and help; human validation required; [S1] but no PDF p. 3. |
| AI disclosure | 0.2 | 1 | 1 | 0 | Same essential instructions; [S1] but no PDF p. 3. |
| **Total, 1.0** | | **4/5** | **5/5** | **1/5** | **10/15 frozen checks** |
| **Total, 0.2** | | **4/5** | **5/5** | **1/5** | **10/15 frozen checks** |

These counts do not imply perfect factuality: each grounding check targets specific failure modes in its case, and this is one non-blinded sample per configuration.
